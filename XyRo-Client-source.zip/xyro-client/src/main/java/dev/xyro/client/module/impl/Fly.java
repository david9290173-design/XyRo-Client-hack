package dev.xyro.client.module.impl;

import dev.xyro.client.module.Category;
import dev.xyro.client.module.Module;
import net.minecraft.client.MinecraftClient;

public class Fly extends Module {
    public Fly() { super("Fly", "Creative-style flight (singleplayer / allowed servers)", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient mc) {
        mc.player.getAbilities().allowFlying = true;
        mc.player.getAbilities().setFlySpeed(0.08f);
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (!mc.player.isCreative() && !mc.player.isSpectator()) {
            mc.player.getAbilities().allowFlying = false;
            mc.player.getAbilities().flying = false;
        }
        mc.player.getAbilities().setFlySpeed(0.05f);
    }
}
