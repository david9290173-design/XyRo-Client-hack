package dev.xyro.client.module;

public enum Category {
    VISUALS("Visuals"), MOVEMENT("Movement"), PLAYER("Player"), PERFORMANCE("Performance");
    public final String label;
    Category(String label) { this.label = label; }
}
