package dev.xyro.client.module.impl;

import dev.xyro.client.module.Category;
import dev.xyro.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;

/** Applies an aggressive low-overhead profile and restores the player's old settings on disable. */
public class FpsBoost extends Module {
    private int view, sim, blend, mip, maxFps;
    private double entityDist;
    private boolean shadows, vsync;
    private ParticlesMode particles;
    private CloudRenderMode clouds;
    private GraphicsMode graphics;

    public FpsBoost() { super("FPS Boost", "Max-performance render profile", Category.PERFORMANCE); }

    @Override
    public void onEnable() {
        GameOptions o = MinecraftClient.getInstance().options;
        view = o.getViewDistance().getValue();
        sim = o.getSimulationDistance().getValue();
        blend = o.getBiomeBlendRadius().getValue();
        mip = o.getMipmapLevels().getValue();
        maxFps = o.getMaxFps().getValue();
        entityDist = o.getEntityDistanceScaling().getValue();
        shadows = o.getEntityShadows().getValue();
        vsync = o.getEnableVsync().getValue();
        particles = o.getParticles().getValue();
        clouds = o.getCloudRenderMode().getValue();
        graphics = o.getGraphicsMode().getValue();

        o.getViewDistance().setValue(6);
        o.getSimulationDistance().setValue(5);
        o.getBiomeBlendRadius().setValue(0);
        o.getMipmapLevels().setValue(0);
        o.getMaxFps().setValue(260);
        o.getEntityDistanceScaling().setValue(0.5);
        o.getEntityShadows().setValue(false);
        o.getEnableVsync().setValue(false);
        o.getParticles().setValue(ParticlesMode.MINIMAL);
        o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        o.getGraphicsMode().setValue(GraphicsMode.FAST);
    }

    @Override
    public void onDisable() {
        GameOptions o = MinecraftClient.getInstance().options;
        o.getViewDistance().setValue(view);
        o.getSimulationDistance().setValue(sim);
        o.getBiomeBlendRadius().setValue(blend);
        o.getMipmapLevels().setValue(mip);
        o.getMaxFps().setValue(maxFps);
        o.getEntityDistanceScaling().setValue(entityDist);
        o.getEntityShadows().setValue(shadows);
        o.getEnableVsync().setValue(vsync);
        o.getParticles().setValue(particles);
        o.getCloudRenderMode().setValue(clouds);
        o.getGraphicsMode().setValue(graphics);
    }
}
