package dev.xyro.client.gui;

import dev.xyro.client.module.EspConfig;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** Search any block and tap it to add/remove it from Block ESP. */
public class BlockPickerScreen extends Screen {
    private static final int ROW_H = 24, ROWS = 8, CARD_W = 270;
    private final Screen parent;
    private TextFieldWidget search;
    private final List<Block> results = new ArrayList<>();

    public BlockPickerScreen(Screen parent) { super(Text.literal("Choose blocks")); this.parent = parent; }

    private int cx() { return (width - CARD_W) / 2; }
    private int cy() { return 70; }

    @Override
    protected void init() {
        search = new TextFieldWidget(textRenderer, cx(), 38, CARD_W, 20, Text.literal("Search"));
        search.setPlaceholder(Text.literal("Search blocks (diamond, chest, obsidian...)"));
        search.setChangedListener(s -> refresh());
        addDrawableChild(search);
        setInitialFocus(search);
        refresh();
    }

    private void refresh() {
        String q = search.getText().toLowerCase().trim();
        results.clear();
        // chosen blocks first, then matches
        for (String id : EspConfig.blocks) {
            var ident = net.minecraft.util.Identifier.tryParse(id);
            if (ident != null && Registries.BLOCK.containsId(ident) && id.contains(q)) results.add(Registries.BLOCK.get(ident));
        }
        for (Block b : Registries.BLOCK) {
            if (results.size() >= ROWS) break;
            if (b == Blocks.AIR || results.contains(b)) continue;
            if (Registries.BLOCK.getId(b).getPath().contains(q)) results.add(b);
        }
        while (results.size() > ROWS) results.remove(results.size() - 1);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, "Block ESP  -  " + EspConfig.blocks.size() + " selected", width / 2, 20, 0xFFFFFFFF);
        Glass.pane(ctx, cx(), cy(), CARD_W, ROWS * ROW_H + 8, 16, 1f);
        int y = cy() + 4;
        for (Block b : results) {
            String id = Registries.BLOCK.getId(b).toString();
            boolean on = EspConfig.has(id);
            Glass.roundRect(ctx, cx() + 12, y + 6, 10, 10, 3, 0xFF000000 | EspConfig.color(id));
            ctx.drawTextWithShadow(textRenderer, b.getName().getString(), cx() + 30, y + 8, 0xFFFFFFFF);
            int sx = cx() + CARD_W - 12 - 34, sy = y + 3;
            Glass.roundRect(ctx, sx, sy, 34, 18, 9, on ? 0xFFF2F2F7 : 0xFF2A2A2E);
            Glass.roundRect(ctx, sx + (on ? 18 : 2), sy + 2, 14, 14, 7, on ? 0xFF000000 : 0xFFE5E5EA);
            y += ROW_H;
        }
        if (results.isEmpty()) ctx.drawCenteredTextWithShadow(textRenderer, "No blocks found", width / 2, cy() + 20, 0xFF8A8A8A);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int y = cy() + 4;
        for (Block b : results) {
            if (mx >= cx() && mx < cx() + CARD_W && my >= y && my < y + ROW_H) {
                EspConfig.toggle(Registries.BLOCK.getId(b).toString());
                return true;
            }
            y += ROW_H;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override public void close() { client.setScreen(parent); }
    @Override public boolean shouldPause() { return false; }
}
