package dev.xyro.client.gui;

import net.minecraft.client.gui.DrawContext;

/** Small helpers that draw the black "liquid glass" look with iOS-style rounded corners. */
public final class Glass {
    private Glass() {}

    public static void roundRect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w, h) / 2);
        for (int i = 0; i < h; i++) {
            int inset = 0;
            if (i < r) inset = r - (int) Math.round(Math.sqrt(r * r - (double) (r - i - 0.5) * (r - i - 0.5)));
            else if (i >= h - r) { int k = h - i - 1; inset = r - (int) Math.round(Math.sqrt(r * r - (double) (r - k - 0.5) * (r - k - 0.5))); }
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
        }
    }

    /** Frosted black pane: dark body, thin light rim, soft top highlight. */
    public static void pane(DrawContext c, int x, int y, int w, int h, int r, float strength) {
        int body = ((int) (170 * strength) << 24);
        roundRect(c, x - 1, y - 1, w + 2, h + 2, r + 1, 0x38FFFFFF);          // rim
        roundRect(c, x, y, w, h, r, body);                                       // glass body
        roundRect(c, x + 2, y + 1, w - 4, Math.max(2, h / 3), r, 0x12FFFFFF);   // specular sheen
    }

    public static int lerpColor(int a, int b, float t) {
        int ar = a >> 16 & 255, ag = a >> 8 & 255, ab = a & 255, aa = a >>> 24;
        int br = b >> 16 & 255, bg = b >> 8 & 255, bb = b & 255, ba = b >>> 24;
        return ((int) (aa + (ba - aa) * t) << 24) | ((int) (ar + (br - ar) * t) << 16)
                | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }
}
