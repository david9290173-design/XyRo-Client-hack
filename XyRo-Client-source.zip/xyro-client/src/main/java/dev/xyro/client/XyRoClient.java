package dev.xyro.client;

import dev.xyro.client.gui.ClickGuiScreen;
import dev.xyro.client.gui.Hud;
import dev.xyro.client.module.ModuleManager;
import dev.xyro.client.net.XyRoNetwork;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class XyRoClient implements ClientModInitializer {
    public static final String ID = "xyro";
    public static final String NAME = "XyRo";
    public static final Identifier CAPE = Identifier.of(ID, "textures/cape.png");
    public static final Identifier LOGO = Identifier.of(ID, "logo.png");

    public static ModuleManager modules;
    private static KeyBinding openGui, panicKey;

    @Override
    public void onInitializeClient() {
        modules = new ModuleManager();

        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xyro.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.create(Identifier.of(ID, "main"))));

        panicKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xyro.panic", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F8,
                KeyBinding.Category.create(Identifier.of(ID, "main"))));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openGui.wasPressed()) mc.setScreen(new ClickGuiScreen());
            while (panicKey.wasPressed()) { modules.panic(); mc.setScreen(null); }
            if (mc.player != null && mc.world != null) modules.tick(mc);
            XyRoNetwork.tick(mc);
        });

        HudRenderCallback.EVENT.register(Hud::render);
        modules.registerWorldRender();
    }
}
