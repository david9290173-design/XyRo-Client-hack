package dev.xyro.client.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;

public abstract class Module {
    public final String name, description;
    public final Category category;
    private boolean enabled;
    public float anim; // 0..1 used by the GUI toggle animation

    protected Module(String name, String description, Category category) {
        this.name = name; this.description = description; this.category = category;
    }

    public boolean isEnabled() { return enabled; }
    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        if (value) onEnable(); else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick(MinecraftClient mc) {}

    /** Return a settings screen (opened with right-click in the menu) or null if none. */
    public Screen settings(Screen parent) { return null; }
}
