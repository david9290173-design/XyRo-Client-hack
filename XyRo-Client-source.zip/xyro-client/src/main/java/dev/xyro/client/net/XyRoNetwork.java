package dev.xyro.client.net;

import net.minecraft.client.MinecraftClient;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tells the XyRo backend "this UUID runs XyRo" and pulls the list of other XyRo users,
 * so capes and the badge are only shown for people who actually use the client.
 */
public final class XyRoNetwork {
    // CHANGE THIS to the address of your server/server.js deployment.
    private static final String API = "http://localhost:8080";

    private static final Set<UUID> USERS = ConcurrentHashMap.newKeySet();
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(4)).build();
    private static int ticks;

    private XyRoNetwork() {}

    public static boolean isUser(UUID id) { return USERS.contains(id); }

    public static void tick(MinecraftClient mc) {
        if (mc.player == null) return;
        USERS.add(mc.player.getUuid()); // you always see your own cape
        if (ticks++ % 200 != 0) return;
        UUID self = mc.player.getUuid();
        Thread.startVirtualThread(() -> {
            try {
                HTTP.send(HttpRequest.newBuilder(URI.create(API + "/hello/" + self))
                        .timeout(Duration.ofSeconds(4)).POST(HttpRequest.BodyPublishers.noBody()).build(),
                        HttpResponse.BodyHandlers.discarding());
                String body = HTTP.send(HttpRequest.newBuilder(URI.create(API + "/users"))
                        .timeout(Duration.ofSeconds(4)).GET().build(), HttpResponse.BodyHandlers.ofString()).body();
                for (String line : body.split("\n")) {
                    try { USERS.add(UUID.fromString(line.trim())); } catch (IllegalArgumentException ignored) {}
                }
            } catch (Exception ignored) { /* backend offline: just no cosmetics for others */ }
        });
    }
}
