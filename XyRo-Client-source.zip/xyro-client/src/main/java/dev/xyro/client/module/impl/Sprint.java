package dev.xyro.client.module.impl;

import dev.xyro.client.module.Category;
import dev.xyro.client.module.Module;
import net.minecraft.client.MinecraftClient;

public class Sprint extends Module {
    public Sprint() { super("Auto Sprint", "Always sprint while moving", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.player.input.hasForwardMovement() && !mc.player.isSneaking() && !mc.player.horizontalCollision)
            mc.player.setSprinting(true);
    }
}
