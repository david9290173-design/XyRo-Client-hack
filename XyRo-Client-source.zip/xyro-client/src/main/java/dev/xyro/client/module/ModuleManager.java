package dev.xyro.client.module;

import dev.xyro.client.module.impl.*;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public final List<Module> all = new ArrayList<>();
    public final BlockEsp blockEsp = new BlockEsp();
    public final BaseFinder baseFinder = new BaseFinder();

    public ModuleManager() {
        all.add(blockEsp);
        all.add(baseFinder);
        all.add(new Fullbright());
        all.add(new Sprint());
        all.add(new Fly());
        all.add(new FpsBoost());
    }

    public List<Module> in(Category c) {
        return all.stream().filter(m -> m.category == c).toList();
    }

    public void panic() { for (Module m : all) m.setEnabled(false); }

    public void tick(MinecraftClient mc) {
        for (Module m : all) if (m.isEnabled()) m.onTick(mc);
    }

    public void registerWorldRender() {
        WorldRenderEvents.AFTER_TRANSLUCENT.register(ctx -> {
            if (blockEsp.isEnabled()) blockEsp.render(ctx);
            if (baseFinder.isEnabled()) baseFinder.render(ctx);
        });
    }
}
