package dev.xyro.client.module;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.math.MathHelper;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** The blocks the player picked for Block ESP. Saved to config/xyro_esp.txt (one block id per line). */
public final class EspConfig {
    public static final Set<String> blocks = new LinkedHashSet<>();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("xyro_esp.txt");

    static {
        try {
            if (Files.exists(FILE)) blocks.addAll(Files.readAllLines(FILE).stream().map(String::trim).filter(l -> !l.isEmpty()).toList());
            else blocks.addAll(List.of("minecraft:diamond_ore", "minecraft:deepslate_diamond_ore", "minecraft:ancient_debris"));
        } catch (IOException ignored) {}
    }

    private EspConfig() {}

    public static boolean has(String id) { return blocks.contains(id); }

    public static void toggle(String id) {
        if (!blocks.remove(id)) blocks.add(id);
        save();
    }

    public static void save() {
        try { Files.write(FILE, blocks); } catch (IOException ignored) {}
    }

    /** Stable, distinct colour per block id (RGB int). */
    public static int color(String id) {
        return MathHelper.hsvToRgb((id.hashCode() & 0xFFFF) / 65535f, 0.65f, 1f);
    }
}
