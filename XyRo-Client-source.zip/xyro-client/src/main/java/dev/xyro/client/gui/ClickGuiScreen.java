package dev.xyro.client.gui;

import dev.xyro.client.XyRoClient;
import dev.xyro.client.module.Category;
import dev.xyro.client.module.Module;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.List;

public class ClickGuiScreen extends Screen {
    private static Category selected = Category.VISUALS;
    private static final int TILE_W = 74, TILE_H = 46, GAP = 8, ROW_H = 30, CARD_W = 270;

    public ClickGuiScreen() { super(Text.literal("XyRo")); }

    private int dockX() { return (width - (Category.values().length * (TILE_W + GAP) - GAP)) / 2; }
    private int dockY() { return height / 2 - 120; }
    private int cardX() { return (width - CARD_W) / 2; }
    private int cardY() { return dockY() + TILE_H + 16; }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta); // vanilla background blur = the "frosted" base

        ctx.drawCenteredTextWithShadow(textRenderer, "XyRo", width / 2, dockY() - 22, 0xFFFFFFFF);

        // category dock
        int x = dockX();
        for (Category c : Category.values()) {
            boolean sel = c == selected;
            boolean hover = mx >= x && mx < x + TILE_W && my >= dockY() && my < dockY() + TILE_H;
            Glass.pane(ctx, x, dockY(), TILE_W, TILE_H, 14, sel ? 1.0f : hover ? 0.8f : 0.6f);
            if (sel) Glass.roundRect(ctx, x + TILE_W / 2 - 8, dockY() + TILE_H - 7, 16, 2, 1, 0xFFFFFFFF);
            ctx.drawCenteredTextWithShadow(textRenderer, c.label, x + TILE_W / 2, dockY() + TILE_H / 2 - 4,
                    sel ? 0xFFFFFFFF : 0xFFAAAAAA);
            x += TILE_W + GAP;
        }

        // module card
        List<Module> mods = XyRoClient.modules.in(selected);
        int cardH = mods.size() * ROW_H + 12;
        Glass.pane(ctx, cardX(), cardY(), CARD_W, cardH, 16, 1.0f);
        int y = cardY() + 6;
        for (Module m : mods) {
            m.anim += ((m.isEnabled() ? 1f : 0f) - m.anim) * 0.25f;
            ctx.drawTextWithShadow(textRenderer, m.name, cardX() + 14, y + 5, 0xFFFFFFFF);
            ctx.drawTextWithShadow(textRenderer, m.description, cardX() + 14, y + 16, 0xFF8A8A8A);
            // iOS-style switch
            int sx = cardX() + CARD_W - 14 - 34, sy = y + 6;
            Glass.roundRect(ctx, sx, sy, 34, 18, 9, Glass.lerpColor(0xFF2A2A2E, 0xFFF2F2F7, m.anim));
            int kx = sx + 2 + (int) (16 * m.anim);
            Glass.roundRect(ctx, kx, sy + 2, 14, 14, 7, Glass.lerpColor(0xFFE5E5EA, 0xFF000000, m.anim));
            y += ROW_H;
        }
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int x = dockX();
        for (Category c : Category.values()) {
            if (mx >= x && mx < x + TILE_W && my >= dockY() && my < dockY() + TILE_H) { selected = c; return true; }
            x += TILE_W + GAP;
        }
        int y = cardY() + 6;
        for (Module m : XyRoClient.modules.in(selected)) {
            if (mx >= cardX() && mx < cardX() + CARD_W && my >= y && my < y + ROW_H) {
                if (click.button() == 1) {
                    Screen s = m.settings(this);
                    if (s != null) client.setScreen(s);
                } else m.toggle();
                return true;
            }
            y += ROW_H;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override public boolean shouldPause() { return false; }
}
