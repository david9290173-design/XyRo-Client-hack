package dev.xyro.client.gui;

import dev.xyro.client.XyRoClient;
import dev.xyro.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

public class Hud {
    public static void render(DrawContext ctx, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || mc.getDebugHud().shouldShowDebugHud()) return;

        String tag = "XyRo  " + mc.getCurrentFps() + " FPS";
        int w = mc.textRenderer.getWidth(tag) + 16;
        Glass.pane(ctx, 6, 6, w, 20, 10, 0.9f);
        ctx.drawTextWithShadow(mc.textRenderer, tag, 14, 12, 0xFFFFFFFF);

        int y = 6;
        for (Module m : XyRoClient.modules.all) {
            if (!m.isEnabled()) continue;
            int mw = mc.textRenderer.getWidth(m.name) + 14;
            Glass.pane(ctx, ctx.getScaledWindowWidth() - mw - 6, y, mw, 16, 8, 0.8f);
            ctx.drawTextWithShadow(mc.textRenderer, m.name, ctx.getScaledWindowWidth() - mw + 1, y + 4, 0xFFFFFFFF);
            y += 20;
        }
    }
}
