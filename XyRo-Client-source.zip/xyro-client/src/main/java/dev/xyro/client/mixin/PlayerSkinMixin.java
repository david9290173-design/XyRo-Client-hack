package dev.xyro.client.mixin;

import dev.xyro.client.XyRoClient;
import dev.xyro.client.net.XyRoNetwork;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.SkinTextures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Swaps in the XyRo cape for players that use the client. */
@Mixin(AbstractClientPlayerEntity.class)
public abstract class PlayerSkinMixin {
    @Inject(method = "getSkinTextures", at = @At("RETURN"), cancellable = true)
    private void xyro$cape(CallbackInfoReturnable<SkinTextures> cir) {
        AbstractClientPlayerEntity self = (AbstractClientPlayerEntity) (Object) this;
        if (!XyRoNetwork.isUser(self.getUuid())) return;
        SkinTextures o = cir.getReturnValue();
        cir.setReturnValue(new SkinTextures(o.texture(), o.textureUrl(), XyRoClient.CAPE, XyRoClient.CAPE,
                o.model(), o.secure()));
    }
}
