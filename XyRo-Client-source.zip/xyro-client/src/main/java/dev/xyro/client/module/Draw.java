package dev.xyro.client.module;

import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexRendering;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** World-space drawing (all coordinates are relative to the camera). */
public final class Draw {
    private Draw() {}

    public static void line(MatrixStack ms, VertexConsumer vc, Vec3d a, Vec3d b, int rgb) {
        MatrixStack.Entry e = ms.peek();
        Vec3d d = b.subtract(a).normalize();
        float r = (rgb >> 16 & 255) / 255f, g = (rgb >> 8 & 255) / 255f, bl = (rgb & 255) / 255f;
        vc.vertex(e, (float) a.x, (float) a.y, (float) a.z).color(r, g, bl, 1f).normal(e, (float) d.x, (float) d.y, (float) d.z);
        vc.vertex(e, (float) b.x, (float) b.y, (float) b.z).color(r, g, bl, 1f).normal(e, (float) d.x, (float) d.y, (float) d.z);
    }

    public static void box(MatrixStack ms, VertexConsumer vc, Box box, int rgb) {
        VertexRendering.drawBox(ms, vc, box, (rgb >> 16 & 255) / 255f, (rgb >> 8 & 255) / 255f, (rgb & 255) / 255f, 1f);
    }
}
