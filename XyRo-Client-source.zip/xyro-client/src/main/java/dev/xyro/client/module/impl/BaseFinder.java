package dev.xyro.client.module.impl;

import dev.xyro.client.module.Category;
import dev.xyro.client.module.Draw;
import dev.xyro.client.module.Module;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Looks through the chunks the server has sent you and scores them by player-made block entities
 * (chests, barrels, shulkers, ender chests, furnaces, beds, hoppers). Chunks that score high enough
 * get a tracer line from your crosshair plus boxes on the storage. Found bases stay until you leave the world.
 */
public class BaseFinder extends Module {
    private static final int CHUNK_RADIUS = 16, MIN_SCORE = 8, COLOR = 0xFFD60A, STORAGE_COLOR = 0x64D2FF;

    private record Base(BlockPos center, int score, List<BlockPos> storage) {}
    private final Map<ChunkPos, Base> bases = new ConcurrentHashMap<>();
    private int ticks;

    public BaseFinder() { super("Base Finder", "Tracer lines to likely bases", Category.VISUALS); }

    @Override public void onDisable() { bases.clear(); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (ticks++ % 40 != 0) return;
        ChunkPos pc = mc.player.getChunkPos();
        for (int dx = -CHUNK_RADIUS; dx <= CHUNK_RADIUS; dx++)
            for (int dz = -CHUNK_RADIUS; dz <= CHUNK_RADIUS; dz++) {
                WorldChunk ch = mc.world.getChunkManager().getWorldChunk(pc.x + dx, pc.z + dz);
                if (ch == null) continue;
                scan(ch);
            }

    }

    private void scan(WorldChunk ch) {
        int score = 0;
        List<BlockPos> storage = new ArrayList<>();
        for (BlockEntity be : ch.getBlockEntities().values()) {
            // villages (bell) and dungeons/mineshafts (spawner) are natural: skip those chunks
            if (be instanceof BellBlockEntity || be instanceof MobSpawnerBlockEntity) { bases.remove(ch.getPos()); return; }
            if (be instanceof ShulkerBoxBlockEntity || be instanceof EnderChestBlockEntity) { score += 2; storage.add(be.getPos()); }
            else if (be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity) { score += 1; storage.add(be.getPos()); }
            else if (be instanceof AbstractFurnaceBlockEntity || be instanceof BedBlockEntity || be instanceof HopperBlockEntity) score += 1;
        }
        if (score >= MIN_SCORE) bases.put(ch.getPos(), new Base(ch.getPos().getCenterAtY(64), score, storage));
        else bases.remove(ch.getPos());
    }

    public void render(WorldRenderContext ctx) {
        if (ctx.consumers() == null || bases.isEmpty()) return;
        Vec3d cam = ctx.camera().getPos();
        Vec3d start = Vec3d.fromPolar(ctx.camera().getPitch(), ctx.camera().getYaw()); // from the crosshair
        VertexConsumer lines = ctx.consumers().getBuffer(RenderLayer.getLines());
        for (Base b : bases.values()) {
            Vec3d end = Vec3d.ofCenter(avg(b.storage(), b.center())).subtract(cam);
            Draw.line(ctx.matrixStack(), lines, start, end, COLOR);
            int n = 0;
            for (BlockPos p : b.storage()) {
                if (n++ > 48) break;
                Draw.box(ctx.matrixStack(), lines, new Box(p).offset(-cam.x, -cam.y, -cam.z), STORAGE_COLOR);
            }
        }
    }

    private static BlockPos avg(List<BlockPos> list, BlockPos fallback) {
        if (list.isEmpty()) return fallback;
        long x = 0, y = 0, z = 0;
        for (BlockPos p : list) { x += p.getX(); y += p.getY(); z += p.getZ(); }
        return new BlockPos((int) (x / list.size()), (int) (y / list.size()), (int) (z / list.size()));
    }
}
