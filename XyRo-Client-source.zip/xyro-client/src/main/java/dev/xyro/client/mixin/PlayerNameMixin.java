package dev.xyro.client.mixin;

import dev.xyro.client.net.XyRoNetwork;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Adds the XyRo badge in front of nametags of players using the client. */
@Mixin(PlayerEntity.class)
public abstract class PlayerNameMixin {
    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true)
    private void xyro$badge(CallbackInfoReturnable<Text> cir) {
        PlayerEntity self = (PlayerEntity) (Object) this;
        if (!XyRoNetwork.isUser(self.getUuid())) return;
        cir.setReturnValue(Text.literal("\u25C6 XyRo ").formatted(net.minecraft.util.Formatting.WHITE, net.minecraft.util.Formatting.BOLD)
                .append(cir.getReturnValue()));
    }
}
