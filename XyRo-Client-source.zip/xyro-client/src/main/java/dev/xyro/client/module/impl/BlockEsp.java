package dev.xyro.client.module.impl;

import dev.xyro.client.gui.BlockPickerScreen;
import dev.xyro.client.module.Category;
import dev.xyro.client.module.Draw;
import dev.xyro.client.module.EspConfig;
import dev.xyro.client.module.Module;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Map;

public class BlockEsp extends Module {
    private static final int RADIUS = 24, MAX_RESULTS = 3000;
    private final Map<BlockPos, Integer> found = new HashMap<>();
    private int ticks;

    public BlockEsp() { super("Block ESP", "Right-click to choose your blocks", Category.VISUALS); }

    @Override public Screen settings(Screen parent) { return new BlockPickerScreen(parent); }
    @Override public void onDisable() { synchronized (found) { found.clear(); } }

    @Override
    public void onTick(MinecraftClient mc) {
        if (ticks++ % 30 != 0) return;
        Map<Block, Integer> targets = new HashMap<>();
        for (String id : EspConfig.blocks) {
            var ident = net.minecraft.util.Identifier.tryParse(id);
            if (ident != null && Registries.BLOCK.containsId(ident)) targets.put(Registries.BLOCK.get(ident), EspConfig.color(id));
        }
        Map<BlockPos, Integer> result = new HashMap<>();
        if (!targets.isEmpty()) {
            BlockPos c = mc.player.getBlockPos();
            BlockPos.Mutable p = new BlockPos.Mutable();
            outer:
            for (int x = -RADIUS; x <= RADIUS; x++)
                for (int y = -RADIUS; y <= RADIUS; y++)
                    for (int z = -RADIUS; z <= RADIUS; z++) {
                        p.set(c.getX() + x, c.getY() + y, c.getZ() + z);
                        Integer col = targets.get(mc.world.getBlockState(p).getBlock());
                        if (col != null) { result.put(p.toImmutable(), col); if (result.size() >= MAX_RESULTS) break outer; }
                    }
        }
        synchronized (found) { found.clear(); found.putAll(result); }
    }

    public void render(WorldRenderContext ctx) {
        if (ctx.consumers() == null) return;
        Vec3d cam = ctx.camera().getPos();
        VertexConsumer lines = ctx.consumers().getBuffer(RenderLayer.getLines());
        synchronized (found) {
            found.forEach((pos, col) -> Draw.box(ctx.matrixStack(), lines, new Box(pos).offset(-cam.x, -cam.y, -cam.z), col));
        }
    }
}
