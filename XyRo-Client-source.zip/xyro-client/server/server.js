// XyRo backend - zero dependencies. Run: node server.js
// POST /hello/<uuid>  -> marks that player as a XyRo user for 60s
// GET  /users         -> newline-separated UUIDs of active XyRo users
const http = require("http");
const seen = new Map();
const TTL = 60_000;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

http.createServer((req, res) => {
  const now = Date.now();
  for (const [k, t] of seen) if (now - t > TTL) seen.delete(k);
  if (req.method === "POST" && req.url.startsWith("/hello/")) {
    const id = req.url.slice(7);
    if (UUID.test(id)) seen.set(id.toLowerCase(), now);
    res.writeHead(204).end();
  } else if (req.method === "GET" && req.url === "/users") {
    res.writeHead(200, { "Content-Type": "text/plain" }).end([...seen.keys()].join("\n"));
  } else res.writeHead(404).end();
}).listen(process.env.PORT || 8080, () => console.log("XyRo backend up"));
