# XyRo Client (Fabric 1.21.11)

Build: open in IntelliJ (JDK 21) -> Gradle import -> `gradle wrapper` once -> `./gradlew build` -> jar in build/libs.
Run: `./gradlew runClient`. Open menu with RIGHT SHIFT.

Cosmetics backend: `node server/server.js`, then set `API` in `net/XyRoNetwork.java`.
For FPS on top of FPS Boost, also install Sodium + Lithium + Entity Culling from Modrinth.

Controls: RIGHT SHIFT menu, F8 panic (turns every module off). In the menu, right-click "Block ESP" to pick blocks.
Base Finder: enable it and fly/explore; chunks with lots of player-made storage get a yellow line from your crosshair.
